#include "Utils.h"
#include "ui/UI_Base.h"
#include "Input.h"

Utils* Utils::instance = nullptr;

unsigned int GUI::UI_Base::static_ID = 0;

LUCY::Input* LUCY::Input::instance = nullptr;

