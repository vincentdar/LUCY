#pragma once

#define SCREEN_WIDTH 1920
#define SCREEN_HEIGHT 1080

#define SFML_LOGO "Resources/sfml-logo-big-word.png"
#define LOGO_SFX "Resources/LogoSFX.ogg"

#define HERO_ANIMATION_SPRITESHEET_R "Resources/Adventurer/adventurer-Sheet.png"
#define HERO_ANIMATION_SPRITESHEET_L "Resources/Adventurer/adventurer-Sheet-L.png"