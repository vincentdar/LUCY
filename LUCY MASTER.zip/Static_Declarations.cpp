#include "utils/Utils.h"
#include "ui/UI_Base.h"

Utils* Utils::instance = nullptr;

unsigned int GUI::UI_Base::static_ID = 0;
