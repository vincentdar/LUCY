#include "Game.h"

int main()
{
	LUCY::Game game(SCREEN_WIDTH, SCREEN_HEIGHT, "Engine LUCY");
	return EXIT_SUCCESS;
}
