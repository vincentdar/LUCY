#pragma once

// Card itu board yg ada gambarnya

