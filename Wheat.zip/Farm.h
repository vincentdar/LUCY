#pragma once
#include "Wheat.h"

namespace LUCY
{
	class Farm
	{

	};
}
