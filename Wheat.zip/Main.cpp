#include "Game.h"

int main()
{
	//LUCY::Game game(640, 480, "Engine LUCY");
	LUCY::Game game(SCREEN_WIDTH, SCREEN_HEIGHT, "Engine LUCY");
	return EXIT_SUCCESS;
}
